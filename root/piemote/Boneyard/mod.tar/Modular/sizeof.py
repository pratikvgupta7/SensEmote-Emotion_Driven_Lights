def sizeof(format):
        from bitstruct import calcsize
        return calcsize(format)
